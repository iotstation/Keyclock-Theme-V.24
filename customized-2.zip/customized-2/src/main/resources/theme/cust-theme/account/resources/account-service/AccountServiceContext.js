import * as React from "../../keycloak.v2/web_modules/react.js";
export const AccountServiceContext = React.createContext(undefined);
//# sourceMappingURL=AccountServiceContext.js.map